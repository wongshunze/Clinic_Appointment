import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class UIHelper  {
    public VBox createMainLayout(BaseForm personalInfoForm, BaseForm appointmentForm) {
        Label welcomeLabel = new Label("Welcome Dickson Clinic Appointment System");
        welcomeLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        TextArea textArea = new TextArea();
        textArea.setWrapText(true);
        textArea.setEditable(false);

        Button submitButton = createSubmitButton((PersonalInformationForm) personalInfoForm, (AppointmentForm) appointmentForm, textArea);
        Button deleteButton = createDeleteButton((PersonalInformationForm) personalInfoForm, (AppointmentForm) appointmentForm, textArea);

        VBox personalInfoBox = personalInfoForm.createLayout();
        VBox appointmentBox = appointmentForm.createLayout();

        VBox importantNoteBox = createImportantNoteBox();

        VBox mainLayout = new VBox(10, welcomeLabel, personalInfoBox, appointmentBox, 
                                   importantNoteBox, textArea, deleteButton, submitButton);
        mainLayout.setPadding(new Insets(20));

        return mainLayout;
    }

    private VBox createImportantNoteBox() {
        Label noteLabel = new Label("IMPORTANT");
        noteLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: red; -fx-font-weight: bold;");

        Label addressLabel = new Label("Venue: NO, 34, Jalan Mutiara mas 7, Taman Mutiara mas, 81300, Skudai, Johor");
        Label timeLabel = new Label("Our opening hours are 9 AM to 5 PM, and we have a rest period from 1 PM to 2 PM, so please plan your visit accordingly.");
        Label emailLabel = new Label("Our Address: Dickson@gmail.com");

        VBox noteBox = new VBox(5, noteLabel, addressLabel, timeLabel, emailLabel);
        noteBox.setPadding(new Insets(10));
        noteBox.setStyle("-fx-border-color: red; -fx-border-width: 1px;");

        return noteBox;
    }

    private Button createSubmitButton(PersonalInformationForm personalInfoForm, AppointmentForm appointmentForm, TextArea textArea) {
    Button submitButton = new Button("Submit");
    submitButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
    submitButton.setOnAction(event -> {
        // Retrieve values from personalInfoForm
        String name = personalInfoForm.getName();
        String ic = personalInfoForm.getIC();
        String dateOfBirth = personalInfoForm.getDateOfBirth();
        String age = personalInfoForm.getAge();
        String telephone = personalInfoForm.getTelephone();
        String gender = personalInfoForm.getGender();
        String nationality = personalInfoForm.getNationality();
        String ethnicity = personalInfoForm.getEthnicity();
        String email = personalInfoForm.getEmail();
        
        // Retrieve values from appointmentForm
        String venue = appointmentForm.getVenueChoiceBox().getValue();
        String preferredDate = appointmentForm.getPreferredDatePicker().getValue() != null
                ? appointmentForm.getPreferredDatePicker().getValue().toString()
                : "Not selected";
        String preferredTime = appointmentForm.getPreferredTimeChoiceBox().getValue();
        
        if (name.isEmpty() || ic.isEmpty() || email.isEmpty()) {
            showAlert("Error", "Name, IC, and Email are required fields.");
        } else {         
            textArea.setText("Appointment successfully submitted with the following details:\n" +
                    "Name: " + name + "\nIC: " + ic + "\nDate of Birth: " + dateOfBirth + "\n" +
                    "Age: " + age + "\nTelephone: " + telephone + "\nGender: " + gender + "\n" +
                    "Nationality: " + nationality + "\nEthnicity: " + ethnicity + "\nEmail: " + email + "\n" +
                    "Venue: " + venue + "\nPreferred Date: " + preferredDate + "\nPreferred Time: " + preferredTime);
        }
    });
    return submitButton;
}

    private Button createDeleteButton(PersonalInformationForm personalInfoForm, AppointmentForm appointmentForm, TextArea textArea) {
        Button deleteButton = new Button("Delete Appointment");
        deleteButton.setOnAction(event -> {
            personalInfoForm.clear();
            appointmentForm.clear();
            textArea.clear();

            showAlert("Success", "Your appointment has been successfully deleted.");
        });
        return deleteButton;
    }

    public void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}