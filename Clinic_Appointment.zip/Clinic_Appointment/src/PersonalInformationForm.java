import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class PersonalInformationForm extends BaseForm {
    private TextField nameField, icField, ageField, telephoneField, emailField;
    private DatePicker dobPicker;
    private ToggleGroup genderToggleGroup;
    private ChoiceBox<String> nationalityChoiceBox, ethnicityChoiceBox;

    public PersonalInformationForm() {
        super("Personal Information"); 
        initializeComponents();
        layout.getChildren().add(createLayout()); 
    }

    private void initializeComponents() {
        nameField = new TextField();
        icField = new TextField();
        ageField = new TextField();
        telephoneField = new TextField();
        emailField = new TextField();
        dobPicker = new DatePicker();
        genderToggleGroup = new ToggleGroup();
        nationalityChoiceBox = new ChoiceBox<>();
        ethnicityChoiceBox = new ChoiceBox<>();

        nationalityChoiceBox.getItems().addAll("Johor", "Melaka", "Selangor", "Perak", "Kedah", "Kelantan", "Negeri Sembilan", "Pahang", "Penang", "Perlis", "Terengganu", "Sarawak", "Sabah");
        ethnicityChoiceBox.getItems().addAll("Chinese", "Indian", "Malay", "Other");
    }

    @Override
    public VBox createLayout() {
        HBox nameBox = new HBox(5, new Label("Name:"), nameField);
        HBox icBox = new HBox(5, new Label("IC:"), icField);
        HBox dobBox = new HBox(5, new Label("Date of Birth:"), dobPicker);
        HBox ageBox = new HBox(5, new Label("Age:"), ageField);
        HBox telephoneBox = new HBox(5, new Label("Telephone:"), telephoneField);

        RadioButton maleButton = new RadioButton("Male");
        RadioButton femaleButton = new RadioButton("Female");
        maleButton.setToggleGroup(genderToggleGroup);
        femaleButton.setToggleGroup(genderToggleGroup);
        HBox genderBox = new HBox(10, new Label("Gender:"), maleButton, femaleButton);

        HBox nationalityBox = new HBox(5, new Label("Nationality:"), nationalityChoiceBox);
        HBox ethnicityBox = new HBox(5, new Label("Ethnicity:"), ethnicityChoiceBox);
        HBox emailBox = new HBox(5, new Label("Email:"), emailField);

        VBox layout = new VBox(15, nameBox, icBox, dobBox, ageBox, 
                               telephoneBox, genderBox, nationalityBox, ethnicityBox, emailBox);
        layout.setPadding(new Insets(10));
        layout.setAlignment(Pos.CENTER_LEFT);

        return layout;
    }

    @Override
    public void clear() {
        nameField.clear();
        icField.clear();
        ageField.clear();
        telephoneField.clear();
        emailField.clear();
        dobPicker.setValue(null);
        genderToggleGroup.selectToggle(null);
        nationalityChoiceBox.setValue(null);
        ethnicityChoiceBox.setValue(null);
    }

    public String getName() { return nameField.getText(); }
    public String getIC() { return icField.getText(); }
    public String getDateOfBirth() { return dobPicker.getValue() != null ? dobPicker.getValue().toString() : ""; }
    public String getAge() { return ageField.getText(); }
    public String getTelephone() { return telephoneField.getText(); }
    public String getGender() {
        RadioButton selectedRadioButton = (RadioButton) genderToggleGroup.getSelectedToggle();
        return selectedRadioButton != null ? selectedRadioButton.getText() : "";
    }
    public String getNationality() { return nationalityChoiceBox.getValue(); }
    public String getEthnicity() { return ethnicityChoiceBox.getValue(); }
    public String getEmail() { return emailField.getText(); }
}