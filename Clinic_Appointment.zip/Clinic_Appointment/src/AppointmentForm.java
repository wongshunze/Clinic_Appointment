import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class AppointmentForm extends BaseForm {
    private ChoiceBox<String> venueChoiceBox, preferredTimeChoiceBox;
    private DatePicker preferredDatePicker;

    public AppointmentForm() {
        super("Venue, Date, and Time"); 
        initializeComponents();
        layout.getChildren().add(createLayout()); 
    }

    private void initializeComponents() {
        venueChoiceBox = new ChoiceBox<>();
        preferredTimeChoiceBox = new ChoiceBox<>();
        preferredDatePicker = new DatePicker();

        venueChoiceBox.getItems().addAll("Room 1(Dr. Lee)", "Room 2(Dr. Daniel)", "Room 3(Dr. Dasveni)");
        preferredTimeChoiceBox.getItems().addAll("9am-10am", "10am-11am", "11am-12pm", "12pm-1pm", 
                                                 "2pm-3pm", "3pm-4pm", "4pm-5pm", "5pm-6pm", "6pm-7pm", "7pm-8pm");
    }

    @Override
    public VBox createLayout() {
        HBox venueBox = new HBox(5, new Label("Assigned Venue:"), venueChoiceBox);
        HBox dateBox = new HBox(5, new Label("Preferred Date:"), preferredDatePicker);
        HBox timeBox = new HBox(5, new Label("Preferred Time:"), preferredTimeChoiceBox);

        VBox layout = new VBox(15, venueBox, dateBox, timeBox);
        layout.setPadding(new Insets(10));
        layout.setAlignment(Pos.CENTER_LEFT);

        return layout;
    }

    @Override
    public void clear() {
        venueChoiceBox.setValue(null);
        preferredTimeChoiceBox.setValue(null);
        preferredDatePicker.setValue(null);
    }

    public ChoiceBox<String> getVenueChoiceBox() { return venueChoiceBox; }
    public ChoiceBox<String> getPreferredTimeChoiceBox() { return preferredTimeChoiceBox; }
    public DatePicker getPreferredDatePicker() { return preferredDatePicker; }
}
