import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Clinic_Appointment extends Application {

    @Override
    public void start(Stage primaryStage) {
        PersonalInformationForm personalInfoForm = new PersonalInformationForm();
        AppointmentForm appointmentForm = new AppointmentForm();
        UIHelper uiHelper = new UIHelper();

        Scene scene = new Scene(uiHelper.createMainLayout(personalInfoForm, appointmentForm), 1000, 950);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Dickson Clinic Appointment System");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}