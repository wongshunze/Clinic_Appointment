import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public abstract class BaseForm {
    protected VBox layout;
    protected Label titleLabel;

    public BaseForm(String title) {
        this.layout = new VBox(15);
        this.layout.setPadding(new Insets(10));
        
        this.titleLabel = new Label(title);
        this.titleLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");
        
        this.layout.getChildren().add(titleLabel);
    }

    public abstract VBox createLayout();

    public VBox getLayout() {
        return layout;
    }

    public abstract void clear();
}